var express = require('express');
var bodyParser = require('body-parser'); // Charge le middleware de gestion des paramètres
var urlencodedParser = bodyParser.urlencoded({ extended: false });
var app = express();
var server = require('http').createServer(app);
var io = require('socket.io').listen(server);
//var ent = require('ent'); // Pour éviter d'envoyer n'importe quoi
var tableau_tache = []; // rentiendra les items de la todolist

/* On affiche la todolist et le formulaire */
app.get('/', function(req, res) { 
    res.render('todo.ejs', {todolist: tableau_tache});
});

/* On redirige vers la todolist si la page demandée n'est pas trouvée */
app.use(function(req, res, next){
    res.redirect('/');
});

io.sockets.on('connection', function (socket) {
        socket.on('ajout_tache',function(tache){
        if(tache !=''){ // Never trust User Input
       // tache = ent.encode(tache);
        tableau_tache.push(tache);
        socket.broadcast.emit('brod_ajout_tache', tache);
        socket.emit('brod_ajout_tache', tache);
        }});
        
        socket.on('suppression_tache',function(id_supp){
             if(id_supp >= 0 && id_supp < tableau_tache.length){ // Never trust User Input
            tableau_tache.splice(id_supp, 1);     
           socket.broadcast.emit('brod_supp_tache', id_supp,tableau_tache);
            socket.emit('brod_supp_tache', id_supp,tableau_tache);
        }});
    });

server.listen(8080);   