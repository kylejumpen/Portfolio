<?php
// On démarre la session AVANT d'écrire du code HTML
session_start();

?>

<?php
try
{
    $bdd = new PDO('mysql:host=localhost;dbname=test;charset=utf8', 'root', '');
}
catch (Exception $e)
{
        die('Erreur : ' . $e->getMessage());
}

if(isset($_POST["pseudo"]) && isset($_POST["message"]) && !empty($_POST["pseudo"]) && !empty($_POST["message"]))
{
//$req = $bdd -> prepare ('INSERT INTO chat(Pseudo,Message,Date_publication) VALUES(:pseudo_user,:textwant, NOW() )');
$req = $bdd -> prepare('INSERT INTO chat(Pseudo, Message, Date_publication) VALUES(:pseudo_user, :textwant, :datemessage )');
$req -> execute(array('pseudo_user' => strip_tags($_POST["pseudo"]),
'textwant' =>strip_tags($_POST["message"]),
'datemessage' => date('Y-m-d H:i:s')
));
$_SESSION['Pseudo'] = $_POST["pseudo"];
}
header('Location: tp_mini_chat.php');
 ?>

