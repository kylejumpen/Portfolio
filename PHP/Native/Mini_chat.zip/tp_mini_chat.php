<?php
// On démarre la session AVANT d'écrire du code HTML
session_start();

?>

<?php
try
{
    $bdd = new PDO('mysql:host=localhost;dbname=test;charset=utf8', 'root', '');
}
catch (Exception $e)
{
        die('Erreur : ' . $e->getMessage());
}

$reponse = $bdd -> query ('SELECT Pseudo,Message,DAY(Date_publication) AS Jour,
MONTH(Date_publication) AS Mois,YEAR(Date_publication) AS Annee, HOUR(Date_publication) AS Heure,
MINUTE(Date_publication) AS Minute,SECOND(Date_publication) AS Seconde FROM chat ORDER BY Date_publication DESC ');

$table_rempli = FALSE;
if (!empty(($donnees = $reponse -> fetch() )))// voir si on a deja une discussion défini ou pas
{
	$table_rempli = TRUE;
	
} ?>

<!DOCTYPE html>
<html>
	<head>
		<title> Un super site </title>
		<meta charset ="utf-8" />
	</head>
	
	<body>
		<p style="text-align:center; font-size: 30px;"> Bienvenue dans mon devoir <p>
		<p>
			<form method="POST"	action="minichat_post.php" style="text-align:center;">
				<label>Pseudo <input type="textarea" name="pseudo" 
				<?php if(isset($_SESSION['Pseudo'])){ // Si la session est défini, on remet le pseudo antérieur dans la valeur
				?>	
				value="<?php echo $_SESSION['Pseudo']?>"
				<?php
				}
				?>
				 /> </label><br/>
				<label>Message <input type="textarea" name="message" /> </label> <br/>
				<input type="submit" value="Publier le message" />
			</form>
		</p>
		
		<?php if($table_rempli) {
			echo '<p>' .'['.htmlspecialchars($donnees['Jour']).'/'.htmlspecialchars($donnees['Mois']).'/'.htmlspecialchars($donnees['Annee']).' '.htmlspecialchars($donnees['Heure']).':'.htmlspecialchars($donnees['Minute']).':'.htmlspecialchars($donnees['Seconde']).'] <em style="font-weight:bold; font-style:normal;"> '.htmlspecialchars($donnees['Pseudo']).'</em>'.' : '. htmlspecialchars($donnees['Message']). '</p>' ;
			while ($donnees = $reponse->fetch()){
				echo '<p>' .'['.htmlspecialchars($donnees['Jour']).'/'.htmlspecialchars($donnees['Mois']).'/'.htmlspecialchars($donnees['Annee']).' '.htmlspecialchars($donnees['Heure']).':'.htmlspecialchars($donnees['Minute']).':'.htmlspecialchars($donnees['Seconde']).'] <em style="font-weight:bold; font-style:normal;"> '.htmlspecialchars($donnees['Pseudo']).'</em>'.' : '. htmlspecialchars($donnees['Message']). '</p>' ;
			}
		}
		else{
			echo 'Aucune discussion n\'a encore été lancé';
		}
		?>
	</body>
</html>
		