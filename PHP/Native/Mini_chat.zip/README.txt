Bonjour,

Les deux fichier .php doivent �tre dans le m�me fichier pour que le devoir marche.

La base de donn�es utilis�e chez moi s'appelle test (comme dans le cours).
Merci de modifier le chemin d'acc�s du PDO dans les deux fichiers en cas 
d'utilisation d'une base de donn�es au nom diff�rent.
Bonne correction :) .