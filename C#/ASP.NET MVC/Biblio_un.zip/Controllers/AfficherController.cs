﻿using $safeprojectname$.Models;
using $safeprojectname$.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace $safeprojectname$.Controllers
{
    public class AfficherController : Controller
    {
        
        

        public ActionResult Donne_liste_auteur()
        {
            Donnee_a_persister base_data = new Donnee_a_persister();
            if (base_data.afficher_auteurs() == null)
                return Donne_erreur("classic");
            else
            {
                Auteurs reponse = new Auteurs(base_data.afficher_auteurs());
                return View(reponse);
            }
        }

        public ActionResult Donne_liste_livre()
        {
            Donnee_a_persister base_data = new Donnee_a_persister();
            if (base_data.affiche_livres() == null)
             return Donne_erreur("classic") ; 
            else
            {
                Livres reponse = new Livres(base_data.affiche_livres());
                return View(reponse);
            }
        }

        public ActionResult Chercher_livre_par_id_auteur(int? id)
        {
            Donnee_a_persister base_data = new Donnee_a_persister();
            if(id == null)
            {
                return Donne_erreur("classic");
            }
            else
            {
                int id_auteur = (int)id;
                if(base_data.chercher_tout_livre_par_id_auteur(id_auteur) == null)
                { 
                    return Donne_erreur("id_vide");
                }
                else
                { 
                Livres reponse = new Livres(base_data.chercher_tout_livre_par_id_auteur(id_auteur));
                return View(reponse);
                }
            }
        } 

        public ActionResult Chercher_livre_par_id_livre (int? id)
        {
            Donnee_a_persister base_data = new Donnee_a_persister();
            if (id == null)
            {
                return Donne_erreur("classic");
            }
            else
            {
                int id_livre = (int)id;
                if (base_data.chercher_livre_par_id(id_livre) == null)
                    return Donne_erreur("id_vide");
                else
                {
                    Livre reponse = new Livre();
                    reponse = base_data.chercher_livre_par_id(id_livre);
                    return View(reponse);
                }
            }


        }


        [HttpGet]
        public ActionResult Chercher_sequence_partout(int? id)
        {
            return View("Recherche");
        }



        [HttpPost]
        public ActionResult Chercher_sequence_partout(int? id, string recherche)
        {


            Donnee_a_persister base_data = new Donnee_a_persister();
            if (recherche == null) // pas de recherche, pas de resultat
                return Donne_erreur("classic");

            RechercheViewModel vm = new RechercheViewModel();
            
                //on recherche dans les auteurs
                if (base_data.chercher_seq_auteur(recherche) != null)
                vm.Auteurtrouve = new Auteurs(base_data.chercher_seq_auteur(recherche));

            //On recherche dans les titres
            if (base_data.chercher_seq_livre(recherche) != null)
                vm.Livretrouve = new Livres(base_data.chercher_seq_livre(recherche));

            vm.sequence_recherche = recherche;

        
            return View(vm);

        }

        public ActionResult Accueil()
        {
            return View();
        }

        private ActionResult Donne_erreur(string type_erreur)
        {
            // Ceci permettrait de maintenir l'application en rajoutant des cas d'erreur
            if (type_erreur == "id_vide")
                return View("Erreur_id_vide");
            else return View("Erreur_classic");
        }
    }
}