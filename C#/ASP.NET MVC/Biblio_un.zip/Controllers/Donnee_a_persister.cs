﻿using $safeprojectname$.Models;
using System;
using System.Collections.Generic;

namespace $safeprojectname$.Controllers
{
    public class Donnee_a_persister
    {
            // création des données à faire persister
            public Biblio biliotheque { get; private set; }

            public Donnee_a_persister(){

            this.biliotheque = new Biblio();
            //Ajout de client dans la bibliothèque
            Client joe = new Client("Joe LaGachette", "joe_gach@caramail.com");
            Client al = new Client("Al Pacino", "al_pacino@mafia.scarf");

            //Création d'Auteur
            Auteur jake = new Auteur("Jake La Tortue", 1);
            Auteur big = new Auteur("Big Coyle", 2);
            Auteur brave = new Auteur("Spencer Marshall", 3);

            //Ajout des Auteurs dans la bibliotheque
            biliotheque.ajout_auteur(jake);
            biliotheque.ajout_auteur(big);
            biliotheque.ajout_auteur(brave);

            // Date aléatoire
            DateTime date1 = new DateTime(2011, 11, 12);
            DateTime date2 = new DateTime(1990, 3, 17);
            DateTime date3 = new DateTime(1902, 12, 19);
            DateTime date4 = new DateTime(2005, 6, 8);
            DateTime date5 = new DateTime(1885, 8, 2);

            //Création Livre
            Livre delajungle = new Livre("Le livre de la jungle", jake, 12, date1);
            Livre h_p = new Livre("Harry Potter", big, 25, date2);
            Livre dummy = new Livre("C# pour les nuls", brave, 78, date3);
            Livre ushuai = new Livre("Apprendre le parkour", jake, 1205, date4);
            Livre bond = new Livre("Mission Impossible", big, 456, date5);

            //Ajout des 2 clients dans la biblio
            biliotheque.ajout_client(joe);
            biliotheque.ajout_client(al);

            //Ajout des 5 livres dans la biblio
            biliotheque.ajout_livre(delajungle);
            biliotheque.ajout_livre(h_p);
            biliotheque.ajout_livre(dummy);
            biliotheque.ajout_livre(ushuai);
            biliotheque.ajout_livre(bond);

            //Emprunt fait
            joe.Emprunter(delajungle);
            joe.Emprunter(h_p);
            joe.Emprunter(dummy);
            al.Emprunter(ushuai);
            al.Emprunter(bond);
         }

        public Auteur chercher_auteur_par_id(int id_auteur)
        {
            foreach(Auteur temp in biliotheque.auteurs)
                if (temp.Id == id_auteur)
                    return temp;

            return null;
        }

        public Livre chercher_livre_par_id(int id_livre)
        {
            Livre recherche = new Livre();
            recherche = null;
            foreach (Livre livre_temp in this.biliotheque.livres)
                if (livre_temp.identifiant == id_livre)
                    recherche = livre_temp;
            return recherche;
        }

        public List<Auteur> afficher_auteurs() {

            List<Auteur> affiche = new List<Auteur>();
            foreach (Auteur auteur_temp in this.biliotheque.auteurs)
            affiche.Add(auteur_temp);
            
            return affiche;
        }

        public List<Livre> affiche_livres()
        {
            List<Livre> affiche = new List<Livre>();
            foreach (Livre livre_temp in this.biliotheque.livres)
               affiche.Add(livre_temp);  
              
            return affiche;
        }

        public List<Livre> chercher_tout_livre_par_id_auteur(int id_auteur)
        {
            List<Livre> trouve = new List<Livre>();
            foreach (Livre livre_temp in this.biliotheque.livres)
                if (livre_temp.Auteur_du_livre.Id == id_auteur)
                    trouve.Add(livre_temp);
            return trouve;
        }

        public List<Auteur> chercher_seq_auteur(string sequence)
        {
            List<Auteur> auteur_trouve = new List<Auteur>();
            foreach (Auteur auteur_temp in this.biliotheque.auteurs)
                if (auteur_temp.Nom.ToLower().Contains(sequence.ToLower()) == true) // je passe tout en minuscule pour rendre insensible à la casse
                    auteur_trouve.Add(auteur_temp);
            if (auteur_trouve != null)
                return auteur_trouve;
            else return null;             
        }

        public List<Livre> chercher_seq_livre(string sequence)
        {
            List<Livre> livre_trouve = new List<Livre>();
            foreach (Livre livre_temp in this.biliotheque.livres)
                if (livre_temp.Titre.ToLower().Contains(sequence.ToLower()) == true)
                    livre_trouve.Add(livre_temp);
            if (livre_trouve != null)
                return livre_trouve;
            else return null;
        }

        public bool presence_titre_livre(string nv_titre)
        {
            bool temp = false;
             foreach (Livre tempo in this.biliotheque.livres)
                if (nv_titre.ToLower() == tempo.Titre.ToLower())
                    temp = true;

            return temp;

        }

        public void ajout_livre(Livre livreaadd)
        {
            biliotheque.ajout_livre(livreaadd);

        }

    }

}