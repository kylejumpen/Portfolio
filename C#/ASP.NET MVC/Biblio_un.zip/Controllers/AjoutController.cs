﻿using $safeprojectname$.Models;
using System.Collections.Generic;
using System.Web.Mvc;

namespace $safeprojectname$.Controllers
{
    public class AjoutController : Controller
    {



        [HttpGet]
        public ActionResult Ajout_livre()
        {
            Donnee_a_persister data = new Donnee_a_persister();
            List<Auteur> auteur_possible = new List<Auteur>();
            foreach (Auteur temp in data.afficher_auteurs())
                auteur_possible.Add(temp);
            ViewBag.auteur_possible = new SelectList(auteur_possible,"Id","Nom");
            return View();
        }

        [HttpPost]
        public ActionResult Ajout_livre(Livre detaillivreaajouter)
        {
           Donnee_a_persister data = new Donnee_a_persister();
            List<Auteur> auteur_possible = new List<Auteur>();
            foreach (Auteur temp in data.afficher_auteurs())
                auteur_possible.Add(temp);
            ViewBag.auteur_possible = new SelectList(auteur_possible, "Id", "Nom");

            if (data.chercher_auteur_par_id(detaillivreaajouter.Auteur_du_livre.Id) == null)
            {
                ModelState.AddModelError("Auteur_du_livre.Id", "Cette auteur n'est pas issu de la base");
                return View(detaillivreaajouter);

            }

            if (ModelState.IsValid == false)
            {
                return View(detaillivreaajouter);
            }

            if (data.presence_titre_livre(string.Copy(detaillivreaajouter.donne_son_titre())) == true)
            {
                ModelState.AddModelError("Titre", "Ce livre existe déjà dans la base");
                return View(detaillivreaajouter);

            }

            if (string.IsNullOrWhiteSpace(detaillivreaajouter.donne_son_titre()) == true )
            {
                ModelState.AddModelError("Titre", "Ce titre ne peut etre constitué uniquement d'espace");
                return View(detaillivreaajouter);

            }


            detaillivreaajouter.Auteur_du_livre = data.chercher_auteur_par_id(detaillivreaajouter.Auteur_du_livre.Id);


            //Work out
            return View("Livre_eligible", detaillivreaajouter);
        }

    }
}