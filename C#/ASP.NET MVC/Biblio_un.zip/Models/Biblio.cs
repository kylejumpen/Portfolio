﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace $safeprojectname$.Models
{
    public class Biblio
    {
        public List<Client> clients { get; private set; } 
        public List<Livre> livres { get; set; }
        public List<Auteur> auteurs { get; set; }

        public Biblio()
        {
            this.clients = new List<Client>();
            this.livres = new List<Livre>();
            this.auteurs = new List<Auteur>();
        }

        public void ajout_auteur(Auteur nv_auteur)
        {
            Boolean erreur_id = false;
            foreach (Auteur auteur_temp in auteurs)
                if (auteur_temp.Id == nv_auteur.Id)
                    erreur_id = true;
            // On aura pas deux id identique dans la bibliothèque
            if (erreur_id == true)
                throw new IdException("Erreur cette identifiant d'auteur est déjà référencé dans la bibliothèque");
            else
                auteurs.Add(nv_auteur);
        }

        public void ajout_livre(Livre nv_livre) {
            Boolean erreur_id = false;
            foreach (Livre livre_temp in livres)
                if (livre_temp.identifiant == nv_livre.identifiant)
                    erreur_id = true;
            // On aura pas deux id identique dans la bibliothèque
            if (erreur_id == true)
                throw new IdException("Erreur cette identifiant de livre est déjà référencé dans la bibliothèque");
            else
                livres.Add(nv_livre);
        }

        public void ajout_client(Client nv_client) {
            Boolean erreur_id = false;
            foreach (Client client_temp in clients)
                if (client_temp.Email == nv_client.Email)
                    erreur_id = true;
            // On aura pas deux id identique dans la bibliothèque
            if (erreur_id == true)
                throw new IdException("Erreur cette email est déjà référencé dans la bibliothèque");
            else
                clients.Add(nv_client);
        }
        public List<Client> show_client() { return clients; }
        public List<Livre> show_Livre() { return livres; }

    }
}