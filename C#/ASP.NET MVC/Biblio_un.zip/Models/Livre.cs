﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace $safeprojectname$.Models
{
    public class Livre
    {

        [Required] 
        public string Titre { get; set; }

        public int identifiant { get; private set; }

        [Display(Name ="Auteur du livre")] [Required]
        public Auteur Auteur_du_livre { get;  set; }

        [Required] [Display(Name="Date de parution")]
        [DisplayFormat(ApplyFormatInEditMode = true, DataFormatString = "{0:dd/MM/yyyy}")]
        public DateTime date_parution { get; set; } 

        public bool Disponible { get; private set; }
        public string emprunteur { get; private set; }

        public Livre(string titre, Auteur auteur, int idt, DateTime date_paru)
        {
            Titre = titre;
            Auteur_du_livre = auteur;
            identifiant = idt;
            Disponible = true;
            date_parution = date_paru;
        }

        public Livre()
        {
        }

        public void Chez_client(string nv_emprunteur) { Disponible = false; emprunteur = nv_emprunteur; }
        public void Retour_bibli() { Disponible = true; emprunteur = null; }
        public string donne_son_titre() { return Titre; }

    }

        public class Livres : IEnumerable
        {
            private List<Livre> _livres;

            public Livres(List<Livre> aArray)
            {
                _livres = new List<Livre>();
                foreach (Livre temp in aArray)
                    _livres.Add(temp);
            }

            IEnumerator IEnumerable.GetEnumerator()
            {
                return (IEnumerator)GetEnumerator();
            }

            public LivresEnum GetEnumerator()
            {
                return new LivresEnum(_livres);
            }

        public bool IsEmpty()
        {
            return (_livres.Count == 0);
        }


    }

        public class LivresEnum : IEnumerator
        {
            public List<Livre> _lAray;

            int position = -1;

            public LivresEnum(List<Livre> list)
            {
                _lAray = list;
            }

            public bool MoveNext()
            {
                position++;
                return (position < _lAray.Count);
            }

            public void Reset()
            {
                position = -1;
            }

            object IEnumerator.Current
            {
                get
                {
                    return Current;
                }
            }

            public Livre Current
            {
                get
                {
                    try
                    {
                        return _lAray[position];
                    }
                    catch (IndexOutOfRangeException)
                    {
                        throw new InvalidOperationException();
                    }
                }
            }


        }

}