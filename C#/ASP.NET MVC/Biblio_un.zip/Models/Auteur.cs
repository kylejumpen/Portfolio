﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace $safeprojectname$.Models
{

    public class Auteur
    {

        [Required]
        public int Id { get; set; } // identifiant
        public string Nom { get; set; } // nom de l'auteur
       

        public Auteur(string nm_nv_auteur, int id_nv_auteur)
        {
            Nom = nm_nv_auteur;
            Id = id_nv_auteur;
        }

        public Auteur(int id_nv_auteur, string nm_nv_auteur)
        {
            Nom = nm_nv_auteur;
            Id = id_nv_auteur;
        }

        public Auteur()
        {
            Nom = null;
            Id = 0;
        }
    }


 
    public class Auteurs : IEnumerable
    {
        private List<Auteur> _auteurs;
        
        public Auteurs(List<Auteur> aArray)
        {
            _auteurs = new List<Auteur>();
            foreach (Auteur temp in aArray)
                _auteurs.Add(temp);
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return (IEnumerator)GetEnumerator();
        }

        public AuteursEnum GetEnumerator()
        {
            return new AuteursEnum(_auteurs);
        }

        public bool IsEmpty()
        {
            return (_auteurs.Count == 0);
        }

    }

    public class AuteursEnum : IEnumerator
    {
        public List<Auteur> _aAray;

        int position = -1;

        public AuteursEnum(List<Auteur> list)
        {
            _aAray = list;
        }

        public bool MoveNext()
        {
            position++;
            return (position < _aAray.Count);
        }

        public void Reset()
        {
            position = -1;
        }

        object IEnumerator.Current
        {
            get
            {
                return Current;
            }
        }

        public Auteur Current
        {
            get
            {
                try
                {
                    return _aAray[position];
                }
                catch (IndexOutOfRangeException)
                {
                    throw new InvalidOperationException();
                }
            }
        }


    }

   
}

