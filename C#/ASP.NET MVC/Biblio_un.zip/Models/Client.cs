﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace $safeprojectname$.Models
{
    public class Client
    {
        public string Nom { get; private set; }
        public string Email { get; private set; }
        public List<Livre> Emprunt_en_cours { get; private set; }


        public Client(string nom_client, string courriel)
        {
            Nom = nom_client;
            Email = courriel;
            this.Emprunt_en_cours = new List<Livre>();
        }


        public void Emprunter(Livre livre_voulu)
        {
            if (livre_voulu.Disponible == true)
            {
                Emprunt_en_cours.Add(livre_voulu);
                livre_voulu.Chez_client(this.Nom);
            }
        }

        public void Rendre(Livre livre_a_rendre) {
           if(Emprunt_en_cours.Contains(livre_a_rendre)) {
             Emprunt_en_cours.Remove(livre_a_rendre);
             livre_a_rendre.Retour_bibli();
            }
        } //developper batterie de limitation ici

    }
}