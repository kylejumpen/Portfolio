﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace $safeprojectname$.Models
{
    public class IdException : Exception
    {
        public IdException() { }

        public IdException(string message) : base(message) { }

        public IdException(string message, Exception inner) : base(message,inner) { }




    }
}