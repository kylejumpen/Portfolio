﻿using $safeprojectname$.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace $safeprojectname$.ViewModels
{
    public class RechercheViewModel
    {
        public Auteurs Auteurtrouve { get;  set; }
        public Livres Livretrouve { get; set;  }
        public string sequence_recherche { get; set; }

        public RechercheViewModel()
        {
            this.Auteurtrouve = null;
            this.Livretrouve = null;
            this.sequence_recherche = null;

        }

    }

    

}