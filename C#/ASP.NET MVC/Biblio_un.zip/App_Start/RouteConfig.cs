﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace $safeprojectname$
{
    public class RouteConfig
    {
        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");

            routes.MapRoute(
               name: "Chercher_sequence_partout",
               url: "Rechercher/Livre",
               defaults: new { controller = "Afficher", action = "Chercher_sequence_partout", recherche = UrlParameter.Optional }
           );

            routes.MapRoute(
              name: "Ajout_livre",
              url: "Ajouter/Livre",
              defaults: new { controller = "Ajout", action = "Ajout_livre", id = UrlParameter.Optional }
          );

            routes.MapRoute(
               name: "Chercher_livre_par_id_livre",
               url: "Afficher/Livre/{id}",
               defaults: new { controller = "Afficher", action = "Chercher_livre_par_id_livre", id = UrlParameter.Optional }
           );

            routes.MapRoute(
               name: "Chercher_livre_par_auteur",
               url: "Afficher/Auteur/{id}",
               defaults: new { controller = "Afficher", action = "Chercher_livre_par_id_auteur", id = UrlParameter.Optional }
           );

            routes.MapRoute(
             name: "Donne_liste_auteur",
             url: "Afficher/Auteurs",
             defaults: new { controller = "Afficher", action = "Donne_liste_auteur", id = UrlParameter.Optional }
         );

            routes.MapRoute(
            name: "Donne_liste_livre",
            url: "Afficher",
            defaults: new { controller = "Afficher", action = "Donne_liste_livre", id = UrlParameter.Optional }
            );

          routes.MapRoute(
          name: "Default",
          url: "{controller}/{action}/{id}",
          defaults: new { controller = "Afficher", action = "accueil", id = UrlParameter.Optional }


      );



        }
    }
}
